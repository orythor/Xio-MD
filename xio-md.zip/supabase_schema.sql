-- =========================================================
-- XIO-MD — SUPABASE SCHEMA
-- =========================================================
-- Cara pakai:
-- 1. Buka dashboard Supabase project kamu
-- 2. Masuk ke menu "SQL Editor"
-- 3. Klik "New query", tempel SELURUH isi file ini
-- 4. Klik "Run"
--
-- Skema ini bikin 3 tabel:
--   1. messages       -> nyimpen histori pesan buat fitur .antidelete
--   2. viewonce_cache -> nyimpen media view-once buat fitur .rvo
--   3. group_settings -> nyimpen setting on/off per grup (antilink, antimedia, dst)
--      biar settingnya nggak reset kalau bot di-restart
-- =========================================================

-- 1. Tabel histori pesan (buat .antidelete)
create table if not exists messages (
  id bigint generated always as identity primary key,
  message_id text not null,
  chat_jid text not null,
  sender_jid text not null,
  message_type text not null default 'text',
  message_content text,
  media_base64 text,
  created_at timestamptz not null default now()
);

-- Index biar lookup pas pesan dihapus itu cepat
create index if not exists idx_messages_message_id on messages (message_id);
create index if not exists idx_messages_chat_jid on messages (chat_jid);
create index if not exists idx_messages_created_at on messages (created_at);

-- 2. Tabel cache view-once (buat .rvo)
create table if not exists viewonce_cache (
  id bigint generated always as identity primary key,
  message_id text not null,
  chat_jid text not null,
  sender_jid text not null,
  media_type text not null,
  media_base64 text not null,
  caption text,
  created_at timestamptz not null default now()
);

create index if not exists idx_viewonce_message_id on viewonce_cache (message_id);

-- 3. Tabel setting per-grup (antilink, antimedia, antidelete, antispam, dll)
create table if not exists group_settings (
  group_jid text primary key,
  antimedia boolean not null default false,
  antilinkphishing boolean not null default false,
  antilinkgc boolean not null default false,
  antilinkch boolean not null default false,
  antidelete boolean not null default false,
  antispam boolean not null default false,
  is_open boolean not null default true,
  updated_at timestamptz not null default now()
);

-- 4. Tabel owner & admin tambahan bot (buat .addownerbot, .addadmingb)
create table if not exists bot_roles (
  id bigint generated always as identity primary key,
  jid text not null,
  role text not null check (role in ('owner', 'group_admin')),
  group_jid text,
  added_at timestamptz not null default now(),
  unique (jid, role, group_jid)
);

-- =========================================================
-- AUTO-CLEANUP: hapus histori pesan/viewonce yang lebih dari 3 hari
-- biar tabel nggak membengkak terus-terusan (opsional, tapi disarankan)
-- =========================================================
create or replace function cleanup_old_messages()
returns void as $$
begin
  delete from messages where created_at < now() - interval '3 days';
  delete from viewonce_cache where created_at < now() - interval '3 days';
end;
$$ language plpgsql;

-- Catatan: Supabase free tier tidak menyediakan pg_cron secara default.
-- Bot ini akan menjalankan pembersihan otomatis dari sisi Node.js
-- (lihat lib/cleanup.js), jadi kamu TIDAK WAJIB setup pg_cron manual.
-- Kalau mau setup cron di level database sebagai cadangan, aktifkan
-- extension pg_cron dulu di Database > Extensions, baru jalankan:
--
-- select cron.schedule('cleanup-xio-md', '0 3 * * *', 'select cleanup_old_messages();');

-- =========================================================
-- ROW LEVEL SECURITY
-- =========================================================
-- Karena bot pakai anon key (bukan service_role key), RLS wajib
-- diaktifkan dan dikasih policy supaya key ini bisa baca/tulis
-- keempat tabel di atas TAPI TETAP TERBATAS ke tabel-tabel ini saja
-- (bukan ke tabel lain yang mungkin kamu bikin di project yang sama).

alter table messages enable row level security;
alter table viewonce_cache enable row level security;
alter table group_settings enable row level security;
alter table bot_roles enable row level security;

drop policy if exists "xio_md_messages_all" on messages;
create policy "xio_md_messages_all" on messages
  for all using (true) with check (true);

drop policy if exists "xio_md_viewonce_all" on viewonce_cache;
create policy "xio_md_viewonce_all" on viewonce_cache
  for all using (true) with check (true);

drop policy if exists "xio_md_group_settings_all" on group_settings;
create policy "xio_md_group_settings_all" on group_settings
  for all using (true) with check (true);

drop policy if exists "xio_md_bot_roles_all" on bot_roles;
create policy "xio_md_bot_roles_all" on bot_roles
  for all using (true) with check (true);

-- SELESAI. Setelah run script ini, isi .env kamu dengan
-- SUPABASE_URL dan SUPABASE_ANON_KEY dari Project Settings > API.
