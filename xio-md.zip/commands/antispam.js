const { makeToggleCommand } = require('../lib/toggleCommand')

module.exports = makeToggleCommand({ name: 'antispam', label: 'antispam' })
