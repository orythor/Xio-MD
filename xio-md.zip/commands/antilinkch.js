const { makeToggleCommand } = require('../lib/toggleCommand')

module.exports = makeToggleCommand({ name: 'antilinkch', label: 'antilink channel' })
