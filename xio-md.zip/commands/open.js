const permission = require('../lib/permission')
const store = require('../lib/store')
const messages = require('../lib/messages')

module.exports = {
  name: 'open',
  description: 'Buka grup (semua member bisa kirim pesan)',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    if (!permission.isBotAdmin(sock.user.id, groupMetadata)) {
      return sock.sendMessage(jid, { text: messages.botNotAdmin() }, { quoted: msg })
    }

    try {
      await sock.groupSettingUpdate(groupJid, 'not_announcement')
      await store.setGroupSetting(groupJid, 'is_open', true)
      return sock.sendMessage(jid, { text: '🔓 Grup dibuka, semua member sekarang bisa kirim pesan.' }, { quoted: msg })
    } catch (err) {
      return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
    }
  },
}
