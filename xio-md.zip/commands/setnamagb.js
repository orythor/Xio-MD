const permission = require('../lib/permission')
const messages = require('../lib/messages')

module.exports = {
  name: 'setnamagb',
  aliases: ['setnamegroup'],
  description: 'Ganti nama grup',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, args, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    if (!permission.isBotAdmin(sock.user.id, groupMetadata)) {
      return sock.sendMessage(jid, { text: messages.botNotAdmin() }, { quoted: msg })
    }

    const newName = args.join(' ').trim()
    if (!newName) {
      return sock.sendMessage(jid, { text: '⚠️ Contoh: .setnamagb Nama Grup Baru' }, { quoted: msg })
    }

    try {
      await sock.groupUpdateSubject(groupJid, newName)
      return sock.sendMessage(jid, { text: '✅ Nama grup berhasil diganti.' }, { quoted: msg })
    } catch (err) {
      return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
    }
  },
}
