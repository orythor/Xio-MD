const permission = require('../lib/permission')
const messages = require('../lib/messages')

module.exports = {
  name: 'setdeskripsi',
  aliases: ['setdesc'],
  description: 'Ganti deskripsi grup',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, args, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    if (!permission.isBotAdmin(sock.user.id, groupMetadata)) {
      return sock.sendMessage(jid, { text: messages.botNotAdmin() }, { quoted: msg })
    }

    const newDesc = args.join(' ').trim()
    if (!newDesc) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Contoh: .setdeskripsi Grup resmi komunitas kita' },
        { quoted: msg },
      )
    }

    try {
      await sock.groupUpdateDescription(groupJid, newDesc)
      return sock.sendMessage(jid, { text: '✅ Deskripsi grup berhasil diganti.' }, { quoted: msg })
    } catch (err) {
      return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
    }
  },
}
