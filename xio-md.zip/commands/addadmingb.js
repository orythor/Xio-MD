const permission = require('../lib/permission')
const store = require('../lib/store')
const messages = require('../lib/messages')
const { getMentionedJids } = require('../lib/helpers')

module.exports = {
  name: 'addadmingb',
  description: 'Tambah admin bot khusus grup ini (bisa akses command ∆ tapi cuma di grup ini)',
  category: 'admin',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    const mentioned = getMentionedJids(msg.message)
    if (mentioned.length === 0) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Tag orang yang mau dijadikan admin bot grup ini. Contoh: .addadmingb @user' },
        { quoted: msg },
      )
    }

    const target = mentioned[0]
    const ok = await store.addRole(target, 'group_admin', groupJid)

    if (!ok) {
      return sock.sendMessage(jid, { text: messages.errorGeneric('gagal menyimpan admin baru') }, { quoted: msg })
    }

    return sock.sendMessage(
      jid,
      { text: `✅ @${target.split('@')[0]} sekarang jadi admin bot di grup ini.`, mentions: [target] },
      { quoted: msg },
    )
  },
}
