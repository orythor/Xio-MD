const { makeToggleCommand } = require('../lib/toggleCommand')

module.exports = makeToggleCommand({ name: 'antimedia', label: 'antimedia' })
