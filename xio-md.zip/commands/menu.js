const fs = require('fs')
const path = require('path')
const messages = require('../lib/messages')
const { kapsul } = require('../lib/font')

const startTime = Date.now()

function formatRuntime() {
  const diff = Date.now() - startTime
  const hours = Math.floor(diff / 3600000)
  const minutes = Math.floor((diff % 3600000) / 60000)
  return `${hours}j ${minutes}m`
}

module.exports = {
  name: 'menu',
  aliases: ['help', 'start'],
  description: 'Nampilin daftar semua fitur bot',
  category: 'all',
  roleNeeded: 'all',
  async execute({ sock, msg, sender, pushName, totalFitur }) {
    const jid = msg.key.remoteJid
    const caption = messages.fullMenu({
      pushName,
      totalFitur,
      runtime: formatRuntime(),
    }).replace('{tag}', sender.split('@')[0])

    const imgPath = path.join(__dirname, '..', 'assets', 'menu.jpg')
    const hasImage = fs.existsSync(imgPath)

    if (hasImage) {
      await sock.sendMessage(
        jid,
        {
          image: fs.readFileSync(imgPath),
          caption,
          mentions: [sender],
        },
        { quoted: msg },
      )
    } else {
      // Fallback teks doang kalau assets/menu.jpg belum ada
      await sock.sendMessage(
        jid,
        { text: caption, mentions: [sender] },
        { quoted: msg },
      )
    }
  },
}
