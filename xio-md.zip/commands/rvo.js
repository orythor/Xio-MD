const messages = require('../lib/messages')
const store = require('../lib/store')
const { getQuotedInfo } = require('../lib/helpers')

module.exports = {
  name: 'rvo',
  description: 'Buka ulang pesan foto/video sekali lihat (view once) yang di-reply',
  category: 'all',
  roleNeeded: 'all',
  async execute({ sock, msg, sender }) {
    const jid = msg.key.remoteJid
    const quoted = getQuotedInfo(msg.message)

    if (!quoted) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Reply pesan view-once yang mau dibuka, terus ketik .rvo' },
        { quoted: msg },
      )
    }

    const quotedMessage = quoted.message
    const viewOnceContent =
      quotedMessage?.viewOnceMessage?.message ||
      quotedMessage?.viewOnceMessageV2?.message ||
      quotedMessage?.viewOnceMessageV2Extension?.message

    // Kasus 1: pesan view-once masih "hidup" di context (baru dikirim, belum expired)
    if (viewOnceContent) {
      const { downloadMediaMessage } = require('baileys')
      try {
        const buffer = await downloadMediaMessage({ message: viewOnceContent, key: msg.key }, 'buffer', {})
        const isVideo = !!viewOnceContent.videoMessage
        const caption = viewOnceContent.imageMessage?.caption || viewOnceContent.videoMessage?.caption || ''

        return sock.sendMessage(
          jid,
          isVideo ? { video: buffer, caption } : { image: buffer, caption },
          { quoted: msg },
        )
      } catch (err) {
        return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
      }
    }

    // Kasus 2: pesan view-once sudah "terpakai"/hilang dari context,
    // coba ambil dari cache Supabase (kalau bot sempat nyimpen sebelumnya)
    const cached = await store.getViewOnce(quoted.stanzaId)
    if (cached) {
      const buffer = Buffer.from(cached.media_base64, 'base64')
      return sock.sendMessage(
        jid,
        cached.media_type === 'video'
          ? { video: buffer, caption: cached.caption || '' }
          : { image: buffer, caption: cached.caption || '' },
        { quoted: msg },
      )
    }

    return sock.sendMessage(
      jid,
      { text: '⚠️ Pesan yang di-reply bukan view-once, atau sudah tidak tersedia lagi.' },
      { quoted: msg },
    )
  },
}
