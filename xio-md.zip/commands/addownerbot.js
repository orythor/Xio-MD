const permission = require('../lib/permission')
const store = require('../lib/store')
const messages = require('../lib/messages')
const { getMentionedJids } = require('../lib/helpers')

module.exports = {
  name: 'addownerbot',
  description: 'Tambah owner bot tambahan (bisa akses semua command ∆ di semua grup)',
  category: 'owner',
  roleNeeded: 'owner',
  async execute({ sock, msg, sender }) {
    const jid = msg.key.remoteJid

    // Hanya owner utama/tambahan yang boleh nambah owner baru,
    // biar nggak ada eskalasi izin dari admin grup biasa.
    const isOwner = await permission.isOwner(sender)
    if (!isOwner) {
      return sock.sendMessage(jid, { text: messages.onlyOwner() }, { quoted: msg })
    }

    const mentioned = getMentionedJids(msg.message)
    if (mentioned.length === 0) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Tag orang yang mau dijadikan owner bot. Contoh: .addownerbot @user' },
        { quoted: msg },
      )
    }

    const target = mentioned[0]
    const ok = await store.addRole(target, 'owner')

    if (!ok) {
      return sock.sendMessage(jid, { text: messages.errorGeneric('gagal menyimpan owner baru') }, { quoted: msg })
    }

    return sock.sendMessage(
      jid,
      { text: `✅ @${target.split('@')[0]} sekarang jadi owner bot.`, mentions: [target] },
      { quoted: msg },
    )
  },
}
