const permission = require('../lib/permission')
const messages = require('../lib/messages')
const { getQuotedInfo } = require('../lib/helpers')

module.exports = {
  name: 'delete',
  aliases: ['del', 'hapus'],
  description: 'Hapus pesan yang di-reply/tag',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    const quoted = getQuotedInfo(msg.message)
    if (!quoted) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Reply/tag pesan yang mau dihapus, terus ketik .delete' },
        { quoted: msg },
      )
    }

    try {
      await sock.sendMessage(jid, {
        delete: {
          remoteJid: jid,
          fromMe: false,
          id: quoted.stanzaId,
          participant: quoted.participant,
        },
      })
    } catch (err) {
      return sock.sendMessage(
        jid,
        { text: messages.errorGeneric('gagal hapus pesan (mungkin bot bukan admin, atau pesan bukan dari grup ini)') },
        { quoted: msg },
      )
    }
  },
}
