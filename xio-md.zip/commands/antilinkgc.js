const { makeToggleCommand } = require('../lib/toggleCommand')

module.exports = makeToggleCommand({ name: 'antilinkgc', label: 'antilink grup' })
