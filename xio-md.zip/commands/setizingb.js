const permission = require('../lib/permission')
const messages = require('../lib/messages')

module.exports = {
  name: 'setizingb',
  description: 'Atur izin kirim pesan grup: .setizingb admin (cuma admin) / .setizingb semua (semua member)',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, args, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    if (!permission.isBotAdmin(sock.user.id, groupMetadata)) {
      return sock.sendMessage(jid, { text: messages.botNotAdmin() }, { quoted: msg })
    }

    const mode = (args[0] || '').toLowerCase()
    if (mode !== 'admin' && mode !== 'semua') {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Gunakan: .setizingb admin (cuma admin bisa kirim pesan) atau .setizingb semua (semua member bisa kirim pesan)' },
        { quoted: msg },
      )
    }

    try {
      await sock.groupSettingUpdate(groupJid, mode === 'admin' ? 'announcement' : 'not_announcement')
      return sock.sendMessage(
        jid,
        { text: `✅ Izin kirim pesan diubah jadi: ${mode === 'admin' ? 'hanya admin' : 'semua member'}` },
        { quoted: msg },
      )
    } catch (err) {
      return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
    }
  },
}
