const permission = require('../lib/permission')
const messages = require('../lib/messages')

module.exports = {
  name: 'setppgb',
  description: 'Ganti foto profil grup (reply gambar + .setppgb)',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    if (!permission.isBotAdmin(sock.user.id, groupMetadata)) {
      return sock.sendMessage(jid, { text: messages.botNotAdmin() }, { quoted: msg })
    }

    const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
    const imageMessage = quotedMsg?.imageMessage || msg.message?.imageMessage

    if (!imageMessage) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Reply/kirim gambar dengan caption .setppgb' },
        { quoted: msg },
      )
    }

    try {
      const { downloadMediaMessage } = require('baileys')
      const buffer = await downloadMediaMessage(
        { message: { imageMessage }, key: msg.key },
        'buffer',
        {},
      )
      await sock.updateProfilePicture(groupJid, buffer)
      return sock.sendMessage(jid, { text: '✅ Foto profil grup berhasil diganti.' }, { quoted: msg })
    } catch (err) {
      return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
    }
  },
}
