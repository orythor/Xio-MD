const { makeToggleCommand } = require('../lib/toggleCommand')

module.exports = makeToggleCommand({ name: 'antidelete', label: 'antidelete' })
