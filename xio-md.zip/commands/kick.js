const permission = require('../lib/permission')
const messages = require('../lib/messages')
const { getMentionedJids, getQuotedInfo } = require('../lib/helpers')

module.exports = {
  name: 'kick',
  aliases: ['tendang'],
  description: 'Keluarkan member dari grup',
  category: 'jaga-group',
  roleNeeded: 'admin',
  async execute({ sock, msg, sender, groupJid, groupMetadata }) {
    const jid = msg.key.remoteJid

    if (!groupJid) {
      return sock.sendMessage(jid, { text: messages.onlyGroup() }, { quoted: msg })
    }

    const hasAccess = await permission.hasAdminAccess(sender, groupJid, groupMetadata)
    if (!hasAccess) {
      return sock.sendMessage(jid, { text: messages.onlyAdmin() }, { quoted: msg })
    }

    if (!permission.isBotAdmin(sock.user.id, groupMetadata)) {
      return sock.sendMessage(jid, { text: messages.botNotAdmin() }, { quoted: msg })
    }

    // Target bisa dari mention (@user) atau dari reply pesan orang tersebut
    let target = getMentionedJids(msg.message)[0]
    if (!target) {
      const quoted = getQuotedInfo(msg.message)
      target = quoted?.participant
    }

    if (!target) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Tag atau reply pesan member yang mau dikick. Contoh: .kick @user' },
        { quoted: msg },
      )
    }

    // Jangan bisa kick sesama admin/owner biar nggak disalahgunakan
    const targetIsAdmin = permission.isGroupAdmin(target, groupMetadata)
    if (targetIsAdmin) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Nggak bisa kick sesama admin grup.' },
        { quoted: msg },
      )
    }

    try {
      await sock.groupParticipantsUpdate(groupJid, [target], 'remove')
      return sock.sendMessage(
        jid,
        { text: `✅ @${target.split('@')[0]} berhasil dikeluarkan dari grup.`, mentions: [target] },
        { quoted: msg },
      )
    } catch (err) {
      return sock.sendMessage(jid, { text: messages.errorGeneric(err.message) }, { quoted: msg })
    }
  },
}
