const chalk = require('chalk')

const config = require('./lib/config')
const { startXioMD } = require('./lib/connection')
const { loadCommands, parseCommand } = require('./lib/commandHandler')
const permission = require('./lib/permission')
const messages = require('./lib/messages')
const events = require('./lib/events')
const { scheduleCleanup } = require('./lib/cleanup')

console.log(chalk.magenta(`
╭───✧〔 ${config.botName} 〕✧───
│ Versi   : ${config.version}
│ Prefix  : ${config.prefix}
│ Login   : ${config.loginMethod}
╰──────────────
`))

const commands = loadCommands()

startXioMD((sock) => {
  events.registerGroupParticipantEvents(sock)
  events.registerAntideleteEvent(sock)
  scheduleCleanup()

  sock.ev.on('messages.upsert', async ({ messages: msgs, type }) => {
    if (type !== 'notify') return

    for (const msg of msgs) {
      try {
        if (!msg.message || msg.key.fromMe) continue
        // protocolMessage (revoke) sudah ditangani terpisah di events.js
        if (msg.message.protocolMessage) continue

        const jid = msg.key.remoteJid
        const isGroup = jid.endsWith('@g.us')
        const sender = isGroup ? msg.key.participant : jid
        const pushName = msg.pushName || 'User'

        const text =
          msg.message.conversation ||
          msg.message.extendedTextMessage?.text ||
          msg.message.imageMessage?.caption ||
          msg.message.videoMessage?.caption ||
          ''

        const parsed = parseCommand(text)

        let groupMetadata = null
        if (isGroup) {
          try {
            groupMetadata = await sock.groupMetadata(jid)
          } catch (err) {
            console.error('[INDEX] Gagal ambil groupMetadata:', err.message)
          }
        }

        // --- Jalankan command kalau pesan diawali prefix ---
        if (parsed) {
          const cmd = commands.get(parsed.commandName)
          if (cmd) {
            await cmd.execute({
              sock,
              msg,
              sender,
              pushName,
              args: parsed.args,
              groupJid: isGroup ? jid : null,
              groupMetadata,
              totalFitur: new Set([...commands.values()].map((c) => c.name)).size,
            })
          }
          continue // pesan command nggak perlu diproses guard (antimedia dkk)
        }

        // --- Kalau bukan command & ini grup, jalankan guard jaga-grup ---
        if (isGroup && groupMetadata) {
          const isSenderAdmin = await permission.hasAdminAccess(sender, jid, groupMetadata)
          await events.handleGroupGuard(sock, msg, jid, groupMetadata, sender, isSenderAdmin)
        }
      } catch (err) {
        console.error(chalk.red('[INDEX] Error proses pesan:'), err)
      }
    }
  })
})
